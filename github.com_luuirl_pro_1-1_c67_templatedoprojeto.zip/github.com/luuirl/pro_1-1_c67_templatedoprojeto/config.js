import firebase from 'firebase';

// adicione SDK do Firebase
var firebaseConfig = {
 apiKey: "AIzaSyDy_DXZ1sKx6vAS7s9pMv6yUfTCWrPyrQA",
  authDomain: "c-57-codeaberto.firebaseapp.com",
  projectId: "c-57-codeaberto",
  storageBucket: "c-57-codeaberto.appspot.com",
  messagingSenderId: "924504253108",
  appId: "1:924504253108:web:776caf363926321e662de1"
};
// Initialice o Firebase
firebase.initializeApp(firebaseConfig);

export default firebase.database();